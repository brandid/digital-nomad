Digital Nomad Theme for BrandID
A WordPress Personal Branding Theme from brandiD

PURCHASE
https://thebrandidthemes.com/product/digital-nomad-personal-branding-wordpress-theme/

INSTALL
1. Make sure you have the Genesis Framework installed first.
2. Go to WordPress dashboard. Click Appearance -> Themes and then Add New, then Upload Theme.
3. Click Choose File and Upload the digital-nomad.zip
4. Activate the Digital Nomad theme.

For theme documentation, please visit https://thebrandidthemes.com/category/digital-nomad-theme/.

NOTE: Digital Nomad theme uses minified css and js files. The uncompressed files are included, but if you edit them, you'll need to recreate the minified versions.
If you want to test using uncompressed js files, add a constant DIGITAL_NOMAD_DEBUG and set to true in your wp-config.php file.

define( 'DIGITAL_NOMAD_DEBUG', true );

See changelog.md for changes.

THEME DEMO
https://digitalnomad.personalbranding.thebrandid.com/

SUPPORT
Please visit https://thebrandidthemes.com/category/digital-nomad-theme/#support-form for theme support.
