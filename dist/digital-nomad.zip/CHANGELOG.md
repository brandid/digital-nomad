# Digital Nomad Theme Changelog
## [1.0.0] - Initial release.
## [1.0.1] - Enable the default Genesis archive page template.
## [1.0.2] - Reduced left padding on header from 50px to 25px for med/large screens.
           - Added code to adjust consent box on comment form.
           - Updated width of comment fields to 100% on mobile.
           - Update Front Page Grid section to add max width and reduce padding on large screens.
## [1.0.3] - Add left padding on nav 40px and reduce calc for width for med/large screens.
